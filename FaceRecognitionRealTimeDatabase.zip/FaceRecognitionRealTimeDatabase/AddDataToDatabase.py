import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

cred = credentials.Certificate("serviceAccount.json")
firebase_admin.initialize_app(cred, {
    'databaseURL':"https://faceattendancesystem-5d1aa-default-rtdb.firebaseio.com/"
})

ref = db.reference('Students')

data = {
    "2022510012":
        {
            "Name": "Piruthviraj",
            "Branch": "AI and DS",
            "Parents Number": '+919962514034',
            "Total_attendance": 35,
            "Cumulative Grade Point Average": 9.86,
            "Year": 'Current: 2,Batch: 2022',
            "Last_attendance_time": "2024-02-12 00:53:32"
        },
    "2022510015":
        {
            "Name": "Udith",
            "Branch": "AI and DS",
            "Parents Number": '+919840650637',
            "Total_attendance":20,
            "Cumulative Grade Point Average": 9.9,
            "Year": 'Current: 2,Batch: 2022',
            "Last_attendance_time": "2024-02-12 00:54:34"
        },
    "2022510022":
        {
            "Name": "Surya",
            "Branch": "AI and DS",
            "Parents Number": '+919840650637',
            "Total_attendance": 20,
            "Cumulative Grade Point Average": 9.5,
            "Year": 'Current: 2,Batch: 2022',
            "Last_attendance_time": "2024-02-12 00:50:20"
        },
    "2022510027":
        {
            "Name": "Thirushika S",
            "Branch": "AI and DS",
            "Parents Number": '+918825889853',
            "Total_attendance": 20,
            "Cumulative Grade Point Average": 10,
            "Year": 'Current: 2,Batch: 2022',
            "Last_attendance_time": "2024-02-12 00:56:34"
        },
    "2022510053":
        {
            "Name": "Srilakshmi",
            "Branch": "AI and DS",
            "Parents Number": '+919840650637',
            "Total_attendance": 32,
            "Cumulative Grade Point Average": 9,
            "Year": 'Current: 2,Batch: 2022',
            "Last_attendance_time": "2024-02-12 00:36:52"
        }
}

for key,value in data.items():
    ref.child(key).set(value)

