import cv2
import os
import pickle
import cvzone
import numpy as np
import face_recognition
import firebase_admin
from firebase_admin import credentials, db, storage
from datetime import datetime
from twilio.rest import Client
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

# Twilio credentials
TWILIO_ACCOUNT_SID = 'ACc8789fbc7a82f82ef22d44b4726b9b1a'
TWILIO_AUTH_TOKEN = 'fd403e08894d6b2893f0edee80426d01'
TWILIO_PHONE_NUMBER = '+17013943971'

# Initialize Twilio client
twilio_client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

def send_sms(recipient_number, message_body):
    message = twilio_client.messages.create(
        body=message_body,
        from_=TWILIO_PHONE_NUMBER,
        to=recipient_number
    )
    print("SMS Sent! SID:", message.sid)


# Firebase credentials initialization
cred = credentials.Certificate("serviceAccount.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': "https://faceattendancesystem-5d1aa-default-rtdb.firebaseio.com/",
    'storageBucket': "faceattendancesystem-5d1aa.appspot.com"
})
bucket = storage.bucket()

cap = cv2.VideoCapture(0)  # Try different indices (0, 1, 2, ...) if 1 doesn't work
if not cap.isOpened():
    print("Error: Unable to open camera.")
    exit()

# Set resolution
cap.set(3, 640)
cap.set(4, 480)

# Load background image
imgBackground = cv2.imread('Resources/background.png')

# Load mode images
folderModePath = 'Resources/Modes'
modePathList = os.listdir(folderModePath)
imgModeList = [cv2.imread(os.path.join(folderModePath, path)) for path in modePathList]

# Load encoding file
print("Loading Encode File...")
file = open('EncodeFile.p', 'rb')
encodeListKnownWithIds = pickle.load(file)
file.close()
encodeListKnown, studentIds = encodeListKnownWithIds
print("Encode File Loaded")

modeType = 0
counter = 0
id = -1
imgStudent = []
message_sent = False

# Function to generate PDF report for students with attendance below 75%
def generate_pdf_report(student_info_list):
    pdf_filename = "Attendance_Report.pdf"
    report_directory = "C:/Users/LENOVO/Documents"  # Specify the directory path where you want to save the PDF report
    pdf_path = os.path.join(report_directory, pdf_filename)
    c = canvas.Canvas(pdf_path, pagesize=letter)
    c.setFont("Helvetica", 12)
    c.drawString(50, 750, "Attendance Report for Students with Attendance Below 75%")
    c.drawString(50, 730, "-" * 70)
    y_position = 700
    for student_info in student_info_list:
        c.drawString(50, y_position, f"Name: {student_info['Name']}")
        c.drawString(50, y_position - 20, f"ID: {student_info['ID']}")
        c.drawString(50, y_position - 40, f"Total Attendance: {student_info['Total_attendance']}")
        c.drawString(50, y_position - 60, f"Attendance Percentage: {student_info['Attendance_percentage']:.2f}%")
        y_position -= 90
    c.save()
    return pdf_path

# Function to check attendance percentage and generate PDF report for students with attendance below 75%
def check_attendance_and_generate_report():
    low_attendance_students = []
    for id in studentIds:
        studentInfo = db.reference(f'Students/{id}').get()
        if studentInfo:
            total_attendance = studentInfo.get('Total_attendance', 0)
            attendance_percentage = (total_attendance / 45) * 100
            if attendance_percentage < 75:
                low_attendance_students.append({
                    'Name': studentInfo.get('Name'),
                    'ID': id,
                    'Total_attendance': total_attendance,
                    'Attendance_percentage': attendance_percentage
                })
    if low_attendance_students:
        # Generate PDF report for students with low attendance
        pdf_path = generate_pdf_report(low_attendance_students)
        print(f"PDF report generated and saved at: {pdf_path}")

while True:
    success, img = cap.read()
    if not success:
        print("Error: Failed to read frame.")
        break

    imgS = cv2.resize(img, (0, 0), None, 0.25, 0.25)
    imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB)

    faceCurFrame = face_recognition.face_locations(imgS)
    encodeCurFrame = face_recognition.face_encodings(imgS, faceCurFrame)

    imgBackground[162:162 + 480, 55:55 + 640] = img
    imgBackground[44:44 + 633, 808:808 + 414] = imgModeList[modeType]

    if faceCurFrame:
        for encodeFace, faceLoc in zip(encodeCurFrame, faceCurFrame):
            matches = face_recognition.compare_faces(encodeListKnown, encodeFace)
            faceDis = face_recognition.face_distance(encodeListKnown, encodeFace)

            matchIndex = np.argmin(faceDis)

            if matches[matchIndex]:
                y1, x2, y2, x1 = faceLoc
                y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4
                bbox = 55 + x1, 162 + y1, x2 - x1, y2 - y1
                imgBackground = cvzone.cornerRect(imgBackground, bbox, rt=0)
                id = studentIds[matchIndex]
                if counter == 0:
                    cvzone.putTextRect(imgBackground, "Loading", (275, 400))
                    cv2.imshow("Face Attendance", imgBackground)
                    cv2.waitKey(1)
                    counter = 1
                    modeType = 1

                if counter != 0:
                    if counter == 1:
                        studentInfo = db.reference(f'Students/{id}').get()
                        print(studentInfo)

                        blob = bucket.get_blob(f'Images/{id}.png')
                        array = np.frombuffer(blob.download_as_string(), np.uint8)
                        imgStudent = cv2.imdecode(array, cv2.COLOR_BGRA2BGR)

                        datetimeObject = datetime.strptime(studentInfo['Last_attendance_time'], "%Y-%m-%d %H:%M:%S")
                        secondsElapsed = (datetime.now() - datetimeObject).total_seconds()
                        print(secondsElapsed)
                        if secondsElapsed > 30:
                            ref = db.reference(f'Students/{id}')
                            studentInfo['Total_attendance'] += 1
                            ref.child('Total_attendance').set(studentInfo['Total_attendance'])
                            ref.child('Last_attendance_time').set(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

                            # Send SMS to parents - morning arrival message
                            parent_number = studentInfo['Parents Number']
                            send_sms(parent_number, "Good morning! Your child has arrived safely at Anna University's MIT campus. We're excited to kick off another day of learning and growth!")
                        else:
                            modeType = 3
                            counter = 0
                            imgBackground[44:44 + 633, 808:808 + 414] = imgModeList[modeType]
                    if modeType != 3:
                        if 10 < counter < 20:
                            modeType = 2

                        imgBackground[44:44 + 633, 808:808 + 414] = imgModeList[modeType]

                        if counter <= 10:
                            # Add student info to the background image
                            cv2.putText(imgBackground, str(studentInfo['Total_attendance']), (861, 125),
                                        cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1)
                            cv2.putText(imgBackground, str(studentInfo['Branch']), (1006, 550),
                                        cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 1)
                            cv2.putText(imgBackground, str(id), (1006, 493),
                                        cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 1)
                            cv2.putText(imgBackground, str(studentInfo['Cumulative Grade Point Average']), (837, 625),
                                        cv2.FONT_HERSHEY_COMPLEX, 0.6, (100, 100, 100), 1)
                            cv2.putText(imgBackground, str(studentInfo['Parents Number']), (1100, 625),
                                        cv2.FONT_HERSHEY_COMPLEX, 0.5, (100, 100, 100), 1)
                            cv2.putText(imgBackground, str(studentInfo['Year']), (890, 625),
                                        cv2.FONT_HERSHEY_COMPLEX, 0.5, (100, 100, 100), 1)

                            (w, h), _ = cv2.getTextSize(studentInfo['Name'], cv2.FONT_HERSHEY_COMPLEX, 1, 2)
                            offset = (414 - w) // 2
                            cv2.putText(imgBackground, str(studentInfo['Name']), (808 + offset, 445),
                                        cv2.FONT_HERSHEY_COMPLEX, 1, (50, 50, 50), 2)

                            imgBackground[175:175 + 216, 909:909 + 216] = imgStudent

                    counter += 1

                    if counter >= 20:
                        counter = 0
                        modeType = 0
                        studentInfo = None
                        imgStudent = []
                        imgBackground[44:44 + 633, 808:808 + 414] = imgModeList[modeType]

    else:
        modeType = 0
        counter = 0

    cv2.imshow("Face Attendance", imgBackground)

    if id != -1 and not message_sent:
        studentInfo = db.reference(f'Students/{id}').get()
        if studentInfo:
            total_attendance = studentInfo.get('Total_attendance', 0)
            attendance_percentage = (total_attendance / 45) * 100
            if attendance_percentage < 75:
                # Send SMS to parents regarding low attendance
                parent_number = studentInfo.get('Parents Number')
                if parent_number:
                    message_body = message_body = f"Dear Parent, We regret to inform you that your child {studentInfo.get('Name')} has attendance below 75%. The current attendance of your child is {attendance_percentage:.2f}%. It's important that you meet with the faculty advisor by tomorrow to discuss ways to improve attendance and academic progress. Thank you for your cooperation."

                    send_sms(parent_number, message_body)
                    message_sent = True

    # Exit if 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Check attendance and generate report
check_attendance_and_generate_report()

cap.release()
cv2.destroyAllWindows()

